import random
import threading
import time

readers_count = 0
readers_count_mutex = threading.Lock()
resource_mutex = threading.Lock()

def reader(reader_id):
    global readers_count
    while True:
        time.sleep(random.random())
        readers_count_mutex.acquire()
        readers_count += 1
        if readers_count == 1:
            resource_mutex.acquire()
        readers_count_mutex.release()

        # Reading section
        print(f"Reader {reader_id} is reading the resource.")
        time.sleep(random.random())

        readers_count_mutex.acquire()
        readers_count -= 1
        if readers_count == 0:
            resource_mutex.release()
        readers_count_mutex.release()

def writer(writer_id):
    while True:
        time.sleep(random.random())
        resource_mutex.acquire()

        # Writing section
        print(f"Writer {writer_id} is writing to the resource.")
        time.sleep(random.random())

        resource_mutex.release()

# Start reader and writer threads
for i in range(3):
    threading.Thread(target=reader, args=(i,)).start()
for i in range(2):
    threading.Thread(target=writer, args=(i,)).start()
