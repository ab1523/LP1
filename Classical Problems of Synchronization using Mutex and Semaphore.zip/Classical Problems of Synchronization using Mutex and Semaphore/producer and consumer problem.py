import threading
import time
import random

buffer = []
buffer_size = 5
mutex = threading.Lock()
empty = threading.Semaphore(buffer_size)  # Buffer starts empty
full = threading.Semaphore(0)  # No items in the buffer initially

def producer():
    while True:
        item = random.randint(1, 100)
        empty.acquire()  # Wait if buffer is full
        mutex.acquire()  # Lock to protect buffer

        buffer.append(item)
        print(f"Producer produced: {item}")

        mutex.release()  # Release lock
        full.release()  # Signal that there is an item in the buffer
        time.sleep(random.random())

def consumer():
    while True:
        full.acquire()  # Wait if buffer is empty
        mutex.acquire()  # Lock to protect buffer

        item = buffer.pop(0)
        print(f"Consumer consumed: {item}")

        mutex.release()  # Release lock
        empty.release()  # Signal that there is space in the buffer
        time.sleep(random.random())

# Start producer and consumer threads
for _ in range(2):
    threading.Thread(target=producer).start()
for _ in range(2):
    threading.Thread(target=consumer).start()

"""This output demonstrates the classic **Producer-Consumer Problem** in concurrent programming, where two threads,
a producer and a consumer, share a common resource, such as a queue or buffer. Here’s an explanation of how this
process works based on your output:

1. **Producer**: The producer generates data (in this case, numbers) and adds them to a shared buffer. Each time 
a message like "Producer produced: 97" appears, the producer has created a new item (here, the number 97) and 
added it to the buffer.

2. **Consumer**: The consumer reads data from the buffer. When you see "Consumer consumed: 97," it means the 
consumer has removed and processed the item 97 from the buffer.

3. **Synchronized Access**: The producer and consumer likely operate within a synchronized structure, ensuring that:
   - The producer does not add items if the buffer is full.
   - The consumer does not consume if the buffer is empty.
   This synchronization prevents issues such as **race conditions** or **data inconsistency**.

4. **Alternating Activity**: Notice the alternating pattern:
   - The producer creates items in quick succession when the buffer is not full.
   - The consumer, running in parallel, removes items as they appear in the buffer.
   - This results in an interleaved output of produced and consumed items, as the two threads work concurrently.

5. **Real-time Adjustment**: When multiple items are produced without being immediately consumed
(e.g., "Producer produced: 53, 46, 31"), this is likely due to the consumer thread catching up as it reads from 
the buffer. The consumer starts clearing the backlog, consuming those items consecutively.

The output represents the balance between production and consumption, with each process pausing when necessary
based on the buffer’s state. This example effectively shows how producer and consumer threads communicate and share
resources in a synchronized manner."""