import threading
import time
import random

NUM_PHILOSOPHERS = 5
forks = [threading.Semaphore(1) for _ in range(NUM_PHILOSOPHERS)]
mutex = threading.Lock()

def philosopher(i):
    while True:
        print(f"Philosopher {i} is thinking.")
        time.sleep(random.random())
        
        # Pick up forks
        mutex.acquire()
        forks[i].acquire()
        forks[(i + 1) % NUM_PHILOSOPHERS].acquire()
        mutex.release()
        
        print(f"Philosopher {i} is eating.")
        time.sleep(random.random())
        
        # Put down forks
        forks[i].release()
        forks[(i + 1) % NUM_PHILOSOPHERS].release()

# Start philosopher threads
for i in range(NUM_PHILOSOPHERS):
    threading.Thread(target=philosopher, args=(i,)).start()
